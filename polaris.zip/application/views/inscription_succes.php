<h3>Vous êtes inscrit !</h3>

<p><?php echo anchor('utilisateur/identification', 'Connectez vous'); ?></p>