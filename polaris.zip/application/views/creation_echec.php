<h3>Échec ! La création de ce personnage n'a pas pu être menée à bout.</h3>

<p><?php echo anchor('personnage/creation', 'Recommencer'); ?></p>