<h3>Création de personnage réussie !</h3>

<p><?php echo anchor('personnage/voir/'.$id_perso, 'Voir le personnage'); ?></p>
